package com.vocalsplit.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp

/**
 * গান থেকে কণ্ঠ ও বাজনা আলাদা করে (center-channel পদ্ধতি, ফোনের ভেতরেই, ইন্টারনেট ছাড়া)।
 * গায়কের কণ্ঠ সাধারণত স্টেরিওর ঠিক মাঝখানে থাকে। মাঝের অংশ (150Hz-এর উপরে) = কণ্ঠ,
 * মূল গান থেকে সেটা বাদ দিলে = বাজনা। বেস/কিক ড্রাম (150Hz-এর নিচে) বাজনার সাথেই থাকে।
 */
object Separator {

    class Pcm(val data: ShortArray, val sampleRate: Int, val channels: Int)

    fun separate(ctx: Context, uri: Uri, onProgress: (Float) -> Unit): Pair<File, File> {
        val pcm = decode(ctx, uri) { onProgress(it * 0.6f) }
        if (pcm.channels < 2) error("এটি মনো গান, তাই কণ্ঠ আলাদা করা যাবে না")

        val ch = pcm.channels
        val frames = pcm.data.size / ch
        val vocal = ShortArray(frames * 2)
        val inst = ShortArray(frames * 2)

        val a = (1.0 - exp(-2.0 * PI * 150.0 / pcm.sampleRate)).toFloat()
        var lp = 0f
        for (n in 0 until frames) {
            val l = pcm.data[n * ch].toFloat()
            val r = pcm.data[n * ch + 1].toFloat()
            val mid = (l + r) * 0.5f
            lp += a * (mid - lp)
            val v = mid - lp
            vocal[2 * n] = clip(v)
            vocal[2 * n + 1] = clip(v)
            inst[2 * n] = clip(l - v)
            inst[2 * n + 1] = clip(r - v)
            if (n % 200_000 == 0) onProgress(0.6f + 0.3f * n / frames)
        }

        val dir = File(ctx.cacheDir, "stems").apply { mkdirs() }
        val vf = File(dir, "vocal.wav")
        val inf = File(dir, "instrumental.wav")
        writeWav(vf, vocal, pcm.sampleRate)
        onProgress(0.95f)
        writeWav(inf, inst, pcm.sampleRate)
        onProgress(1f)
        return vf to inf
    }

    private fun clip(x: Float): Short = x.coerceIn(-32768f, 32767f).toInt().toShort()

    private fun decode(ctx: Context, uri: Uri, onProgress: (Float) -> Unit): Pcm {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)

        var idx = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                idx = i; fmt = f; break
            }
        }
        if (idx < 0 || fmt == null) {
            ex.release()
            error("এই ফাইলে অডিও পাওয়া যায়নি")
        }
        ex.selectTrack(idx)

        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()

        var buf = ShortArray(1 shl 20)
        var len = 0
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false

        while (!outDone) {
            if (!inDone) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val b = codec.getInputBuffer(i)!!
                    val n = ex.readSampleData(b, 0)
                    if (n < 0) {
                        codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inDone = true
                    } else {
                        codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                        ex.advance()
                    }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            when {
                o >= 0 -> {
                    val b = codec.getOutputBuffer(o)!!
                    b.position(info.offset)
                    b.limit(info.offset + info.size)
                    val sb = b.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val cnt = sb.remaining()
                    if (len + cnt > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, len + cnt))
                    sb.get(buf, len, cnt)
                    len += cnt
                    codec.releaseOutputBuffer(o, false)
                    if (durUs > 0) onProgress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
                o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val f = codec.outputFormat
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
        }
        codec.stop()
        codec.release()
        ex.release()
        return Pcm(buf.copyOf(len), sr, ch)
    }

    private fun writeWav(file: File, samples: ShortArray, sampleRate: Int) {
        val dataLen = samples.size * 2
        FileOutputStream(file).use { out ->
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt(36 + dataLen)
            h.put("WAVE".toByteArray()); h.put("fmt ".toByteArray())
            h.putInt(16); h.putShort(1); h.putShort(2)
            h.putInt(sampleRate); h.putInt(sampleRate * 4)
            h.putShort(4); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(dataLen)
            out.write(h.array())
            val chunk = ByteBuffer.allocate(1 shl 16).order(ByteOrder.LITTLE_ENDIAN)
            var i = 0
            while (i < samples.size) {
                chunk.clear()
                val end = minOf(samples.size, i + chunk.capacity() / 2)
                while (i < end) { chunk.putShort(samples[i]); i++ }
                out.write(chunk.array(), 0, chunk.position())
            }
        }
    }
}
