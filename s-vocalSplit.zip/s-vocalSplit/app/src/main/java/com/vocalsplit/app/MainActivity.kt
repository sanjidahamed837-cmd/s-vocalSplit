package com.vocalsplit.app

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App() } } }
    }
}

private class Players {
    var vocal: MediaPlayer? = null
    var inst: MediaPlayer? = null
    fun release() {
        vocal?.release(); inst?.release()
        vocal = null; inst = null
    }
}

private fun displayName(ctx: android.content.Context, uri: Uri): String =
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    } ?: "গান"

@Composable
private fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val players = remember { Players() }

    var title by remember { mutableStateOf("কোনো গান বাছাই করা হয়নি") }
    var progress by remember { mutableStateOf<Float?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var ready by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var vocalVol by remember { mutableStateOf(1f) }
    var instVol by remember { mutableStateOf(1f) }
    var pos by remember { mutableStateOf(0f) }

    DisposableEffect(Unit) { onDispose { players.release() } }

    LaunchedEffect(playing) {
        while (playing) {
            val v = players.vocal
            if (v != null && v.duration > 0) pos = v.currentPosition.toFloat() / v.duration
            delay(250)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            players.release()
            ready = false; playing = false; error = null; pos = 0f
            title = displayName(ctx, uri)
            progress = 0f
            try {
                val (vf, inf) = withContext(Dispatchers.Default) {
                    Separator.separate(ctx, uri) { progress = it }
                }
                withContext(Dispatchers.IO) {
                    players.vocal = MediaPlayer().apply { setDataSource(vf.path); prepare() }
                    players.inst = MediaPlayer().apply { setDataSource(inf.path); prepare() }
                }
                players.vocal?.setVolume(vocalVol, vocalVol)
                players.inst?.setVolume(instVol, instVol)
                players.vocal?.setOnCompletionListener {
                    playing = false; pos = 0f
                    players.vocal?.seekTo(0); players.inst?.seekTo(0)
                }
                ready = true
            } catch (e: Exception) {
                error = e.message ?: "কিছু একটা সমস্যা হয়েছে"
            }
            progress = null
        }
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp).systemBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("s-vocalSplit", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = { picker.launch(arrayOf("audio/*")) }, enabled = progress == null) {
            Text("ফোন থেকে গান বাছাই করুন")
        }
        Text(title, style = MaterialTheme.typography.titleMedium)

        progress?.let {
            Text("কণ্ঠ ও বাজনা আলাদা করা হচ্ছে… ${(it * 100).toInt()}%")
            LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth())
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        if (ready) {
            Button(onClick = {
                val v = players.vocal ?: return@Button
                val i = players.inst ?: return@Button
                if (playing) {
                    v.pause(); i.pause(); playing = false
                } else {
                    i.seekTo(v.currentPosition)
                    v.start(); i.start(); playing = true
                }
            }) { Text(if (playing) "বিরতি" else "বাজান") }

            Slider(
                value = pos,
                onValueChange = { pos = it },
                onValueChangeFinished = {
                    val v = players.vocal ?: return@Slider
                    val t = (pos * v.duration).toInt()
                    v.seekTo(t); players.inst?.seekTo(t)
                }
            )

            Text("কণ্ঠ (লিরিক্স)  ${(vocalVol * 100).toInt()}%")
            Slider(value = vocalVol, onValueChange = {
                vocalVol = it; players.vocal?.setVolume(it, it)
            })

            Text("ব্যান্ডের বাজনা  ${(instVol * 100).toInt()}%")
            Slider(value = instVol, onValueChange = {
                instVol = it; players.inst?.setVolume(it, it)
            })

            Text(
                "কণ্ঠ ০% করলে শুধু বাজনা (কারাওকে), বাজনা ০% করলে শুধু কণ্ঠ শোনা যাবে।",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
